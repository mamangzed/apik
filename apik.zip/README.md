# APIK — Web-Based API Client & Interceptor

A full-featured, **Bruno-inspired** web API client with request interception, environment variables, API documentation, and a browser extension.

---

## Features

| Feature | Description |
|---------|-------------|
| **Request Builder** | GET/POST/PUT/PATCH/DELETE/HEAD/OPTIONS |
| **Collection Manager** | Organize requests, import Postman collections |
| **Clerk Authentication** | Register/login with Clerk, guest mode stays local |
| **Supabase Sync** | Collections and environments sync across devices after login |
| **Environment Variables** | `{{variable}}` substitution in URLs, headers, body |
| **Request Body** | JSON, XML, Text, Form Data, URL-Encoded, GraphQL |
| **Authentication** | Bearer Token, Basic Auth, API Key, OAuth2 |
| **Pre-request Scripts** | JavaScript scripts before sending |
| **Test Scripts** | Validate responses with JS assertions |
| **Monaco Editor** | Syntax-highlighted request/response editor |
| **Intercept Panel** | Capture, inspect, modify and forward/drop requests |
| **API Documentation** | Auto-generate, export, and share public/private docs |
| **Public Share Links** | Public/private collection links without login for viewers |
| **Localhost Support** | Proxy through backend to avoid CORS |
| **Chrome Extension** | Intercept browser XHR/fetch from any page |
| **Firefox Extension** | Same extension (MV3 compatible) |

---

## Quick Start

### 1. Install Dependencies

```bash
cd backend && npm install
cd ../frontend && npm install
```

### 2. Configure Environment Variables

Copy the examples and fill in your real credentials:

```bash
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env
```

Required values:

- `backend/.env`
    - `CLERK_SECRET_KEY`
    - `CLERK_PUBLISHABLE_KEY`
    - `SUPABASE_URL`
    - `SUPABASE_SERVICE_ROLE_KEY`
- `frontend/.env`
    - `VITE_CLERK_PUBLISHABLE_KEY`
    - `VITE_APP_BASE_URL` (e.g. `https://api.example.com`)
    - `VITE_API_BASE_URL` (e.g. `https://api.example.com`)
    - `VITE_WS_BASE_URL` (e.g. `wss://api.example.com`)

### 3. Create Supabase Tables

Run the SQL in [supabase/schema.sql](supabase/schema.sql) inside your Supabase SQL editor.

This creates:

- `apix_collections`
- `apix_environments`
- update triggers for `updated_at`

### 4. Start the Application

**Option A — Use the startup script:**
```
start.bat
```

**Option B — Manual:**
```bash
# Terminal 1: Backend
cd backend
npm run dev

# Terminal 2: Frontend
cd frontend
npm run dev
```

### 5. Open the App

Navigate to **[http://localhost:5173](http://localhost:5173)**

You can download the browser extension directly from the top bar inside the app via the **Extension** button.

## Storage Modes

- Guest mode: collections and environments are saved in browser local storage.
- Logged in: collections and environments are saved in Supabase and sync across devices.
- On first login: local guest data is pushed to Supabase automatically.

## Public and Private Sharing

- Collections can be marked `private` or `public`.
- API docs can be marked `private` or `public` independently.
- Public links are generated from the share modal.
- Public collection links can be opened without login and support trying requests directly.
- Public documentation links can be opened without login.

## Production Startup

Windows:

```bat
start.bat
```

Linux/macOS:

```bash
chmod +x start.sh
./start.sh
```

Background management on Linux/macOS:

```bash
./start.sh start-bg
./start.sh status
./start.sh stop
```

Both scripts will:

- install dependencies if needed
- build backend and frontend
- start the backend in production mode
- serve the built frontend from Express

### VPS + Cloudflare Full Auto Setup (HTTPS + WebSocket + Background Service)

Use the provided deploy script on Ubuntu/Debian VPS:

```bash
chmod +x deploy_cloudflare_vps.sh manage_vps.sh
sudo bash ./deploy_cloudflare_vps.sh
```

The script will prompt for required values if they are not provided via env vars:

- `DOMAIN`
- `PROXY_SUBDOMAIN` (`proxy` or full host like `proxy.example.com`)
- `CF_API_TOKEN`
- `CF_ZONE_ID`
- `CLERK_SECRET_KEY`
- `CLERK_PUBLISHABLE_KEY`
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`

You can also run non-interactively:

```bash
DOMAIN=api.example.com \
PROXY_SUBDOMAIN=proxy \
CF_API_TOKEN=your_token \
CF_ZONE_ID=your_zone_id \
CLERK_SECRET_KEY=sk_live_xxx \
CLERK_PUBLISHABLE_KEY=pk_live_xxx \
SUPABASE_URL=https://xxxx.supabase.co \
SUPABASE_SERVICE_ROLE_KEY=eyJ... \
sudo bash ./deploy_cloudflare_vps.sh
```

Or as a single one-liner (recommended for SSH sessions — fixes CRLF and runs fully automated):

```bash
cd ~/apik && sed -i 's/\r$//' deploy_cloudflare_vps.sh && chmod +x deploy_cloudflare_vps.sh && sudo env \
  DOMAIN='apik.app' \
  PROXY_SUBDOMAIN='proxy' \
  CF_API_TOKEN='your_cf_api_token' \
  CF_ZONE_ID='your_cf_zone_id' \
  CLERK_SECRET_KEY='sk_live_xxx' \
  CLERK_PUBLISHABLE_KEY='pk_live_xxx' \
  SUPABASE_URL='https://xxxx.supabase.co' \
  SUPABASE_SERVICE_ROLE_KEY='eyJ...' \
  INTERCEPT_PROXY_PORT_RANGE='9000-9999' \
  SHOW_SECRET_INPUTS='false' \
  CF_DNS_AUTOMATION='true' \
  bash ./deploy_cloudflare_vps.sh
```

> The `sed -i 's/\r$//'` step strips Windows-style CRLF line endings, which is required when the script was edited on Windows. The `sudo env ...` pattern is used because `sudo` normally strips environment variables — this passes them explicitly to the script.

What it does automatically:

- installs Node.js, Nginx, and required tools
- auto-selects backend port if `BACKEND_PORT` is not set
- normalizes `PROXY_SUBDOMAIN` into a full host inside your Cloudflare zone
- creates/updates a Cloudflare `A` record for the proxy host with `proxied=false` (DNS only)
- verifies the proxy DNS record still points to the VPS public IP and is not orange-cloud proxied
- generates `backend/.env` and `frontend/.env`
- builds backend + frontend
- creates `systemd` service (`apik-backend`) for background running
- generates Cloudflare Origin Certificate and private key via Cloudflare API
- sets Cloudflare SSL mode to `strict`
- configures Nginx reverse proxy for HTTPS + WebSocket (`/ws/intercept`)
- enables restart-on-boot

Service management after deploy:

```bash
./manage_vps.sh status
./manage_vps.sh restart
./manage_vps.sh logs
```

---

## Browser Extension Setup

### DevTools Panel (Chrome/Edge)
After loading the extension, open DevTools on any tab and you will see an **APIK** panel.
The panel shows intercepted requests (method, URL, source, status, request preview, and response preview) in real time.
Right-click an intercepted row and choose **Add To Collection** to save it directly into the `Intercepted Requests` collection in APIK.

### Chrome / Edge
1. Open Chrome → `chrome://extensions/`
2. Enable **Developer mode** (top right)
3. Download `apik-extension.zip` from the app header and extract it
4. Click **Load unpacked**
5. Select the extracted extension folder
6. Click the **APIK** icon in the toolbar
7. Connect to your server WebSocket URL (example: `wss://apik.app/ws/intercept`)
8. Enable **Intercept**

In production, use the extension popup fields:

- `API Base URL`: `https://api.example.com`
- `App Base URL`: `https://api.example.com` (or your frontend domain)
- `WS URL`: `wss://api.example.com/ws/intercept`

### Firefox
1. Open Firefox → `about:debugging#/runtime/this-firefox`
2. Download `apik-extension.zip` from the app header and extract it
3. Click **Load Temporary Add-on**
4. Select the extracted `manifest.json`

### Note on "Encrypted" Payloads
If a website encrypts payload in JavaScript before sending (application-level encryption), the extension can only show the encrypted value because that is what the page sends.
For normal request bodies, APIK now decodes and formats `JSON`, `XML`, `FormData`, `URLSearchParams`, and common text bodies for easier inspection.

> **Note:** First-time setup requires generating icons. See `extension/icons/README.md`

## Mobile Proxy Setup (Android / iPhone)

Intercept panel now includes a built-in **Android/iPhone Proxy Guide** for logged-in users.
It shows per-user proxy host/port, QR helper (CA + WireGuard profile), proxy reachability check, and step-by-step setup.

### Backend env for proxy guide

Optional environment values for backend:

- `INTERCEPT_PROXY_HOST` (example: `proxy.example.com`)
- `INTERCEPT_PROXY_PORT` (default: `8080`)
- `INTERCEPT_CA_DOWNLOAD_URL` (public URL to CA certificate)
- `INTERCEPT_CA_COMMON_NAME` (display label, default: `APIK Local CA`)

If not set, host falls back to backend host and port defaults to `8080`.

### Important notes

- HTTPS inspection requires CA install + trust on the phone.
- Mobile proxy host should use a dedicated DNS-only / grey-cloud subdomain such as `proxy.example.com`.
- If WireGuard transparent intercept is enabled (`INTERCEPT_WIREGUARD_TRANSPARENT_ENABLE=true`), phone proxy can stay `Off/None` after WireGuard tunnel is connected.
- WireGuard transparent redirect targets backend port `INTERCEPT_WIREGUARD_TRANSPARENT_PORT` (default `18080`) and is applied for WireGuard TCP traffic to ports `80` and `443`.
- Apps with certificate pinning may still not be inspectable.
- Use proxy/intercept only on systems and traffic you are authorized to test.

### WireGuard without manual phone proxy

Default behavior now supports no manual proxy setup on mobile when WireGuard is active:

1. Enable WireGuard and import your per-user profile from the Intercept panel.
2. Keep phone Wi-Fi proxy set to `Off/None`.
3. Ensure backend runs as root (or has iptables permission) so PREROUTING redirect can be installed.
4. Verify redirect rules exist on VPS:

```bash
sudo iptables -t nat -S PREROUTING | grep wg0
```

You should see redirect rules to `INTERCEPT_WIREGUARD_TRANSPARENT_PORT` for tcp/80 and tcp/443.

### API endpoints used by setup UI

- `GET /api/intercept/session` (issue user-scoped WS ticket)
- `GET /api/intercept/proxy-setup` (host/port/CA metadata)
- `GET /api/intercept/proxy-health` (backend-to-proxy reachability check)

### Proxy connection monitor (VPS)

To continuously watch whether traffic is entering the proxy, use:

```bash
chmod +x monitor_proxy.sh
./monitor_proxy.sh
```

Optional variables:

- `API_BASE_URL` (default: `http://127.0.0.1:3001`)
- `INTERVAL_SECONDS` (default: `5`)
- `INTERCEPT_MONITOR_KEY` (optional monitor auth key)

If you set `INTERCEPT_MONITOR_KEY` in backend env, monitor endpoint requires key:

- Endpoint: `GET /api/intercept/monitor?key=...`
- Header alternative: `x-monitor-key: ...`

### WireGuard connection monitor (VPS)

To continuously watch incoming traffic on WireGuard peers:

```bash
chmod +x monitor_wireguard.sh
./monitor_wireguard.sh
```

Optional variables:

- `WIREGUARD_INTERFACE` (default: `wg0`)
- `INTERVAL_SECONDS` (default: `5`)

The monitor prints:

- per-peer incoming RX deltas (`INCOMING` lines)
- handshake activity in the last 180 seconds
- periodic total RX/TX summary

### Live proxy + WireGuard monitor (VPS)

To monitor incoming proxy connections and WireGuard traffic in one command:

```bash
chmod +x monitor_intercept_live.sh
./monitor_intercept_live.sh
```

Optional variables:

- `INTERVAL_SECONDS` (default: `3`)
- `WIREGUARD_INTERFACE` (default: value from `backend/.env`, fallback `wg0`)

The script prints:

- active established connections on APIK proxy ports
- top client IPs currently connected to proxy
- WireGuard recent handshakes count
- WireGuard RX/TX deltas (incoming/outgoing bytes per interval)

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    APIK Web App (port 5173)                  │
│  ┌──────────┐  ┌────────────────┐  ┌────────────────────┐  │
│  │ Sidebar  │  │ Request Builder│  │  Response Viewer   │  │
│  │Collections│  │ URL/Method/Tabs│  │ Body/Headers/Stats │  │
│  │Environments│  │ Params/Headers │  │ Timeline/Cookies   │  │
│  └──────────┘  │ Body/Auth/Scripts│  └────────────────────┘  │
│               └────────────────┘                             │
└─────────────────────────────────────────────────────────────┘
          │                              │
          │ REST API                     │ WebSocket
          ▼                              ▼
┌─────────────────────────────────────────────────────────────┐
│               APIK Backend (port 3001)                       │
│  ┌──────────────┐  ┌───────────┐  ┌───────────────────────┐ │
│  │ Proxy Route  │  │Collections│  │  WS Intercept Server  │ │
│  │ (fwd requests│  │Environments│  │  (pending requests)   │ │
│  │  handles CORS│  │  Storage  │  │                       │ │
│  └──────────────┘  └───────────┘  └───────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
                                              │ WebSocket
                                              ▼
                                   ┌──────────────────┐
                                   │ Browser Extension │
                                   │ (MV3 Chrome/FF)   │
                                   │ intercepts XHR    │
                                   │ & fetch from pages│
                                   └──────────────────┘
```

---

## Environment Variables

Use `{{variable_name}}` syntax anywhere in:
- URL: `https://{{base_url}}/api/users`
- Headers: `Authorization: Bearer {{token}}`
- Body: `{"userId": "{{user_id}}"}`

---

## Import Collections

Supports importing:
- **Postman v2.1** collections (JSON)
- **APIK / Bruno** collections (JSON)

Go to sidebar → Upload icon → Select format → Drop file

---

## Project Structure

```
ApiRequest/
├── backend/            # Node.js + Express + WebSocket
│   ├── src/
│   │   ├── index.ts
│   │   ├── types.ts
│   │   ├── routes/
│   │   │   ├── proxy.ts
│   │   │   ├── collections.ts
│   │   │   └── environments.ts
│   │   ├── storage/
│   │   │   └── fileStore.ts
│   │   └── websocket/
│   │       └── intercept.ts
│   └── data/           # Auto-created (collections.json, environments.json)
├── frontend/           # React + Vite + TypeScript + Tailwind
│   └── src/
│       ├── App.tsx
│       ├── store/      # Zustand state
│       ├── types/
│       ├── components/
│       │   ├── Layout/
│       │   ├── RequestBuilder/
│       │   ├── ResponseViewer/
│       │   ├── Environment/
│       │   ├── Intercept/
│       │   ├── ApiDoc/
│       │   └── Collections/
│       └── utils/
├── extension/          # Chrome/Firefox MV3 extension
│   ├── manifest.json
│   ├── background.js
│   ├── content.js
│   ├── injected.js     # Page-context XHR/fetch override
│   └── popup/
└── start.bat           # Quick start script
```
